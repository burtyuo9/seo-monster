#!/bin/bash
# SEO Monster - Installation Script
# Автоматическая установка на новом сервере

set -e

echo "🚀 SEO Monster - Установка"
echo "=========================="

# Проверка Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 не найден. Установите Python 3.9+"
    exit 1
fi

# Проверка Node.js
if ! command -v node &> /dev/null; then
    echo "⚠️ Node.js не найден. Установка frontend будет пропущена."
    SKIP_FRONTEND=1
fi

# Создание виртуального окружения
echo "📦 Создание виртуального окружения..."
python3 -m venv venv
source venv/bin/activate

# Установка зависимостей Python
echo "📦 Установка Python зависимостей..."
pip install --upgrade pip
pip install -r backend/requirements.txt

# Установка frontend (если Node.js доступен)
if [ -z "$SKIP_FRONTEND" ]; then
    echo "📦 Установка frontend зависимостей..."
    cd frontend
    npm install
    cd ..
fi

# Создание директорий
mkdir -p backend/data
mkdir -p backend/services/data/sessions
mkdir -p backend/knowledge
mkdir -p logs

# Настройка прав
chmod +x scripts/*.sh 2>/dev/null || true
chmod +x scripts/*.py 2>/dev/null || true

echo ""
echo "✅ Установка завершена!"
echo ""
echo "Для запуска:"
echo "  1. Активируйте окружение: source venv/bin/activate"
echo "  2. Запустите backend: cd backend && python -m uvicorn main:app --host 0.0.0.0 --port 8000"
echo "  3. Запустите frontend: cd frontend && npm run dev"
echo ""
echo "Или используйте Docker:"
echo "  docker-compose up -d"
